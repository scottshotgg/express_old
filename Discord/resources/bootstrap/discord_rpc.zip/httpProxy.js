'use strict';

module.exports = require('http-proxy');
